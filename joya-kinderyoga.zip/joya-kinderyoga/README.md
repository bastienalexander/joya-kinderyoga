# Joya Kinderyoga - Website Backup

Exported from Framer on 27 maart 2026.
Original URL: https://crooked.framer.website

## Structure
- index.html — main page
- assets/ — fonts, images, scripts

## Note
This is a static snapshot. Interactive Framer features 
(animations, CMS) may not work fully without the Framer runtime.
